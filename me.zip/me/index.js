var person={
    Name:"Ade-Olunusi Olamide",
    Height:162.56,
    Country:Nigeria
}
